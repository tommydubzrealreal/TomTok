# TomTok server edition

TomTok is now a small full-stack app. The browser talks to an Express server; the server stores post metadata in `data/posts.json` and uploaded video files in `uploads/`.

## Run it on your computer

1. Install **Node.js 18 or newer** from https://nodejs.org/
2. Unzip this folder.
3. Open a terminal in the `tomtok-server` folder.
4. Run:

   ```bash
   npm install
   npm start
   ```

5. Open http://localhost:3000

## Included

- Shared feed served by the backend
- Video uploads (MP4, WebM, OGG, MOV; 100 MB max)
- Persistent post metadata, likes, and comments
- Search within loaded posts
- Health check at `/api/health`

## Important limitations before putting it on the public internet

This is a starter project, not a production social network. It has no accounts, sign-in, per-user like tracking, moderation queue, report/block tools, rate limiting, or automated content checks. Likes are shared totals and anyone can post/comment. Add authentication, moderation, abuse protection, secure persistent storage, and backups before inviting the public.

The included JSON file and local upload folder persist only if your hosting provider gives your app a persistent disk/volume. Some free hosting services erase local files when redeploying or restarting. For a public deployment, use a persistent volume or move videos to object storage and metadata to a managed database.

## Deploying

You can deploy this Node app to a Node-compatible host (for example, Render or Railway). Create a new web service from this folder, use `npm install` as the build command and `npm start` as the start command, and configure a persistent disk/volume mounted so the `data` and `uploads` folders survive restarts. Set the service's public URL after deployment. Hosting providers may require a paid plan for persistent storage.

Do not put passwords, API keys, or private credentials in the source files.
